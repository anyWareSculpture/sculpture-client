chrome.app.runtime.onLaunched.addListener(function() {
  chrome.app.window.create('application.html', {
    'outerBounds': {
      'width': 600,
      'height': 500
    }
  });
});
